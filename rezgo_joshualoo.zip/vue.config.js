module.exports = {
	publicPath: "/rezgo/",
};
