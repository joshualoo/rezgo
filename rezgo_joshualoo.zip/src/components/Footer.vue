<template>
    <section class="section">
       <h3 class="is-size-5 has-text-weight-bold has-text-centered">Thanks for considering me! 😀 </h3>
    </section>
</template>

<style scoped>
section.section{
    background: #ADA996;  /* fallback for old browsers */
    background: -webkit-linear-gradient(to right, #EAEAEA, #DBDBDB, #F2F2F2);  /* Chrome 10-25, Safari 5.1-6 */
    background: linear-gradient(to right, #EAEAEA, #DBDBDB, #F2F2F2); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
}
</style>

<script>
    export default {
        name:'Footer',
    }
</script>